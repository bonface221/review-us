$(document).ready(() => {
	$("#site").click(() => {
        $("#ModalCenter").toggle();
        console.log('I was clicked')
	});

});
